# GitHub Image Gallery

## Overview
A static HTML website that displays an image gallery by fetching images from a GitHub repository. Users can view and download individual images or download all images as a ZIP file.

## Project Structure
- `index.html` - Main HTML file containing the gallery application
- `*.PNG` - Local image files

## Technology
- Pure HTML/CSS/JavaScript (no build required)
- Uses JSZip library (loaded from CDN) for ZIP file creation
- Fetches images from GitHub API

## Development
The site is served using Python's built-in HTTP server on port 5000.

## Deployment
Configured as a static site deployment serving the root directory.
